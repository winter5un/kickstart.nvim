local build_push = "build_push"
local build = "build"
local clean = "clean"
local clean_build="clean_build"
local follow_service = "follow_service"
local stop_service = "stop_service"
local start_service = "start_service"
local restart_service = "restart_service"
local ands = " && "
local nextop = "; "
local clear = "clear; "
local cmd = "cmd"
local desc = "desc"
local name = "name"



-- command strings
local main_service = 'connectivity-manager'
local bin_name = main_service
local cd_build = 'cd /home/nicholasmabe/framery_repos/supra2-connectivity-manager/build'
local build_bin = 'source /opt/supra2/environment-setup-aarch64-oe-linux && qmake .. ; make 2>&1 | tee ../build.log'
local list_files = 'ls -tl --full-time | head -n 10'
local zip_files = 'rm ' .. bin_name .. '*.zip; zip -r ' .. bin_name .. '-$(date +"%%FT%%T").zip ' .. bin_name
local push_files = 'adb push ' .. bin_name .. ' /usr/bin || (adb shell "mount -oremount,rw /" && adb push ' .. bin_name .. ' /usr/bin)'
local stop_ui_service = 'adb shell "systemctl stop ' .. main_service .. '"'
local start_ui_service = 'adb shell "systemctl start ' .. main_service .. '"'
local clean_bin = 'rm ' .. bin_name
local clean_files = 'rm *.o; rm *.zip; rm *.cpp; rm *.png; rm *.h; rm ' .. bin_name


commands = {
  ["3"] = {

    ["2"] = {
      [cmd]= clear .. cd_build .. ands .. clean_bin .. nextop .. build_bin .. ands .. list_files .. ands .. zip_files,
      [desc]='Build the ' .. bin_name .. '',
      [name]=build,
    },
    ["1"]={
      [cmd]='clear; ' .. cd_build .. ands .. clean_bin .. nextop .. build_bin .. ands .. list_files .. ands .. stop_ui_service .. ands .. push_files .. ands .. start_ui_service .. ands .. zip_files,
      [desc]='Build and push the ' .. main_service .. '',
      [name]=build_push,
    },
    ["3"] = {
        [cmd]=clear .. cd_build .. ands .. clean_files,
        [desc]='Clean the build files',
        [name]=clean,
    },
    ["4"] = {
      [cmd]=clear .. cd_build .. ands .. clean_files .. ands .. build_bin .. ands .. list_files .. ands .. zip_files,
      [desc]='Clean and rebuild the ' .. main_service .. '',
      [name]=clean_build,
    },
    ["5"] = {
      [cmd]='adb shell "journalctl -fu ' .. main_service .. '.service" 2>&1 | tee ' .. main_service .. '.log',
      [desc]='Follow the ' ..main_service.. ' service logs',
      [name]=follow_service,
    },
    ["6"] = {
      [cmd]=stop_ui_service,
      [desc]='Stop the ' .. main_service .. ' service',
      [name]=stop_service,
    },
    ["7"] = {
      [cmd]=start_ui_service,
      [desc]='Start the ' .. main_service .. ' service',
      [name]=start_service,
    },
    ["8"] = {
      [cmd]=stop_ui_service .. ands .. start_ui_service,
      [desc]='Restart the ' .. main_service .. ' service',
      [name]=restart_service,
    },
    ["0"] = {
      [cmd]= cd_build .. ands .. 'adb shell "touch /tmp/take_screenshot" && sleep 4 && adb pull /tmp/screenshot.png ./ss_$(date +"%%FT%%T").png',
      [desc]='Take a screenshot',
      [name]='screenshot',
    }

  },

}

return commands

