build_push = "build_push"
build = "build"
clean = "clean"
clean_build="clean_build"
follow_service = "follow_service"
stop_service = "stop_service"
start_service = "start_service"
restart_service = "restart_service"
ands = " && "
nextop = "; "
clear = "clear; "
cmd = "cmd"
desc = "desc"
name = "name"



-- command strings
main_service = 'canmanager'
bin_path = '/home/nicholasmabe/framery_repos/cu-platform-sw/build/src/canmanager/'
bin_name = main_service
build_bin = 'source /opt/supra2-1/environment-setup-aarch64-oe-linux && cmake .. ; make '
list_files = 'ls -tl --full-time ' .. bin_path .. ' | head -n 10'
zip_files = 'rm ' .. bin_name .. '*.zip; zip -r ' .. bin_name .. '-$(date +"%%FT%%T").zip ' .. bin_path .. bin_name
push_files = 'adb push ' .. bin_path .. bin_name .. ' /usr/bin'
stop_main_service = 'adb shell "systemctl stop ' .. main_service .. '"'
stop_main_service_bg = 'adb shell "systemctl stop --no-block ' .. main_service .. '"'
start_main_service = 'adb shell "systemctl start ' .. main_service .. '"'
clean_files = 'rm *.o; rm -f *.zip; rm *.cpp; rm *.h; rm ' .. bin_name


commands = {
  ["3"] = {

    ["2"] = {
      [cmd]= clear .. build_bin .. ands .. list_files .. ands .. zip_files,
      [desc]='Build the ' .. bin_name .. '',
      [name]=build,
    },
    ["1"]={
      [cmd]='clear; ' .. stop_main_service_bg .. nextop .. build_bin .. ands .. list_files .. ands .. stop_main_service .. ands .. push_files .. ands .. start_main_service .. ands .. zip_files,
      [desc]='Build and push the ' .. main_service .. '',
      [name]=build_push,
    },
    ["3"] = {
        [cmd]=clear .. clean_files,
        [desc]='Clean the build files',
        [name]=clean,
    },
    ["4"] = {
      [cmd]=clear .. clean_files .. ands .. build_bin .. ands .. list_files .. ands .. zip_files,
      [desc]='Clean and rebuild the ' .. main_service .. '',
      [name]=clean_build,
    },
    ["5"] = {
      [cmd]='adb shell "journalctl -fu ' .. main_service .. '.service" 2>&1 | tee ' .. main_service .. '.log',
      [desc]='Follow the ' ..main_service.. ' service logs',
      [name]=follow_service,
    },
    ["6"] = {
      [cmd]=stop_main_service,
      [desc]='Stop the ' .. main_service .. ' service',
      [name]=stop_service,
    },
    ["7"] = {
      [cmd]=start_main_service,
      [desc]='Start the ' .. main_service .. ' service',
      [name]=start_service,
    },
    ["8"] = {
      [cmd]=stop_main_service .. ands .. start_main_service,
      [desc]='Restart the ' .. main_service .. ' service',
      [name]=restart_service,
    }
  },

}

return commands

