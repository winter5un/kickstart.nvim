local build_push = "build_push"
local build = "build"
local clean = "clean"
local clean_build="clean_build"
local follow_service = "follow_service"
local stop_service = "stop_service"
local start_service = "start_service"
local restart_service = "restart_service"
local ands = " && "
local nextop = "; "
local clear = "clear; "
local cmd = "cmd"
local desc = "desc"
local name = "name"



-- command strings
local main_service = 'supra-modem-controller'
local bin_path = '/home/nicholasmabe/framery_repos/supra-modem-controller/'
local bin_name = main_service
local zip_files = 'rm ' .. bin_path .. bin_name .. '*.zip; zip -r ' .. bin_name .. '-$(date +"%%FT%%T").zip ' .. bin_path .. 'src/' .. '**/*.py'
local build_whl = '.venv/bin/python setup.py bdist_wheel'
-- local push_files_script = "python3 /home/nicholasmabe/.config/projcom/adb-push-tool.py " .. bin_path .. 'src' .. ' /usr/lib/python3.8/site-packages/supra-modem-controller/src/'
local push_whl = 'adb shell "rm tmp/*.whl"; adb push dist/*.whl /tmp/; adb shell "pip3 install --force-reinstall /tmp/*.whl"; sleep 1'
local push_files = push_whl .. ' || (adb shell "mount -oremount,rw / && ' .. push_whl .. '")'
local stop_main_service = 'adb shell "systemctl stop ' .. main_service .. '"'
local start_main_service = 'adb shell "systemctl start ' .. main_service .. '"'
local clean_files = 'rm *supra-modem-controller*.zip; rm -rf docs/diagrams/*; rm -rf build/*; rm -rf dist/*'
local build_diagrams = 'python docs/scripts/build_diagrams.py'
local show_diagrams = 'feh docs/diagrams/*.png'


commands = {
  ["3"] = {
    ["1"]={
      -- [cmd]='clear; ' .. clean_files .. stop_main_service .. ands .. push_files .. ands .. start_main_service .. ands .. zip_files,
      [cmd]='clear; ' .. clean_files .. nextop .. build_whl .. ands .. stop_main_service .. nextop .. push_files .. ands .. start_main_service,
      [desc]='Build and push the ' .. main_service .. '',
      [name]=build_push,
    },
    ["2"] = {
      [cmd]= clear .. '.venv/bin/pytest',
      [desc]='Run local tests',
      [name]="run_tests",
    },
    ["3"] = {
        [cmd]=clear,
        [desc]='Clean the build files',
        [name]=clean,
    },
    ["4"] = {
      [cmd]=clear .. clean_files .. ands .. build_whl,
      [desc]='Clean and rebuild the ' .. main_service .. '',
      [name]=clean_build,
    },
    ["5"] = {
      [cmd]='adb shell "journalctl -fu ' .. main_service .. '.service" 2>&1 | tee ' .. main_service .. '.log',
      [desc]='Follow the ' ..main_service.. ' service logs',
      [name]=follow_service,
    },
    ["6"] = {
      [cmd]=stop_main_service,
      [desc]='Stop the ' .. main_service .. ' service',
      [name]=stop_service,
    },
    ["7"] = {
      [cmd]=start_main_service,
      [desc]='Start the ' .. main_service .. ' service',
      [name]=start_service,
    },
    ["8"] = {
      [cmd]=stop_main_service .. ands .. start_main_service,
      [desc]='Restart the ' .. main_service .. ' service',
      [name]=restart_service,
    },
    ["9"] = {
      [cmd]=clear .. clean_files .. nextop .. build_diagrams .. ands .. show_diagrams,
      [desc]='Clean the doc files',
      [name]="clean_docs",
    }
  },

}

commands["2"] = commands["3"]

return commands

