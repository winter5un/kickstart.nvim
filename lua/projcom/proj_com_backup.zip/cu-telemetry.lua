local build_push = "build_push"
local build = "build"
local clean = "clean"
local clean_build="clean_build"
local follow_service = "follow_service"
local stop_service = "stop_service"
local start_service = "start_service"
local restart_service = "restart_service"
local ands = " && "
local nextop = "; "
local clear = "clear; "
local cmd = "cmd"
local desc = "desc"
local name = "name"



-- command strings
local main_service = 'telemetry'
local bin_path = '/home/nicholasmabe/framery_repos/cu-telemetry/telemetry/'
local bin_name = main_service
local zip_files = 'rm ' .. bin_path .. bin_name .. '*.zip; zip -r ' .. bin_name .. '-$(date +"%%FT%%T").zip ' .. bin_path .. '*.py'
local push_files = 'adb push ' .. bin_path .. '*.py' .. ' /usr/lib/python3.8/site-packages/telemetry/ || (adb shell "mount -oremount,rw /" && adb push ' .. bin_path .. '*.py /usr/lib/python3.8/site-packages/telemetry/)'
local stop_main_service = 'adb shell "systemctl stop ' .. main_service .. '"'
local start_main_service = 'adb shell "systemctl start ' .. main_service .. '"'
local clean_files = 'rm *.o; rm -f *.zip;'


commands = {
  ["3"] = {
    ["1"]={
      [cmd]='clear; ' .. clean_files .. stop_main_service .. ands .. push_files .. ands .. start_main_service .. ands .. zip_files,
      [desc]='Build and push the ' .. main_service .. '',
      [name]=build_push,
    },
    ["2"] = {
      [cmd]= clear .. '.venv/bin/python -m nox -s test_telemetry',
      [desc]='Run telemetry tests',
      [name]="run_tests",
    },
    ["3"] = {
        [cmd]=clear,
        [desc]='Clean the build files',
        [name]=clean,
    },
    ["4"] = {
      [cmd]=clear,
      [desc]='Clean and rebuild the ' .. main_service .. '',
      [name]=clean_build,
    },
    ["5"] = {
      [cmd]='adb shell "journalctl -fu ' .. main_service .. '.service" 2>&1 | tee ' .. main_service .. '.log',
      [desc]='Follow the ' ..main_service.. ' service logs',
      [name]=follow_service,
    },
    ["6"] = {
      [cmd]=stop_main_service,
      [desc]='Stop the ' .. main_service .. ' service',
      [name]=stop_service,
    },
    ["7"] = {
      [cmd]=start_main_service,
      [desc]='Start the ' .. main_service .. ' service',
      [name]=start_service,
    },
    ["8"] = {
      [cmd]=stop_main_service .. ands .. start_main_service,
      [desc]='Restart the ' .. main_service .. ' service',
      [name]=restart_service,
    }
  },

}

return commands

