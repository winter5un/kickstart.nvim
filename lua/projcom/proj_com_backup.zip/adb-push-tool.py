import argparse
from pathlib import Path
import subprocess
from typing import List
from pprint import pformat



def get_parser()->argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Push files to android device using adb")
    parser.add_argument("source", help="Source file or directory to push", type=Path)
    parser.add_argument("destination", help="Destination base directory on device", type=Path)
    return parser

def get_python_file_paths(directory: Path, recursive: bool = True)->List[Path]:
    if directory.is_file():
        return [directory]
    elif directory.is_dir():
        file_paths = []
        for file_path in directory.iterdir():
            if file_path.is_file() and file_path.suffix == ".py":
                file_paths.append(file_path)
            elif file_path.is_dir() and recursive:
                file_paths.extend(get_python_file_paths(file_path, recursive))
        return file_paths
    else:
        return []

def make_directory_on_device(directory: Path, exists_ok: bool = True)->None:
    if exists_ok:
        subprocess.run(["adb", "shell", "mkdir", "-p", str(directory)], check=True)
    else:
        subprocess.run(["adb", "shell", "mkdir", str(directory)], check=True)

def push_file_to_device(source: Path, destination: Path)->None:
    subprocess.run(["adb", "push", str(source), str(destination)], check=True)

def main(args=None):
    parser = get_parser()
    args = parser.parse_args(args)
    print(f"Source: {args.source}")
    print(f"Destination: {args.destination}")
    if not args.source.exists():
        print(f"Error: {args.source} does not exist")
        return

    file_paths = get_python_file_paths(args.source)
    make_directory_on_device(args.destination)
    for file_path in file_paths:
        parent_only = file_path.parts[-2]
        file_destination = args.destination / parent_only / file_path.name
        make_directory_on_device(file_destination.parent)
        print(f"Creating directory {file_destination.parent}")
        push_file_to_device(file_path, file_destination)
        print(f"Pushing {file_path} to {file_destination}")



if __name__ == "__main__":
    main()
